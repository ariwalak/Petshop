<!DOCTYPE HTML>
<?php
    $pgTitle = 'Sandys Pet Shop';
?>
<html>
<head>
<meta charset="utf-8">
<meta name='viewport' content='initial-scale=1.0, width=decive-width'/>
<title><?php echo $pgTitle; ?></title>
<script   src="https://code.jquery.com/jquery-3.0.0.min.js"   integrity="sha256-JmvOoLtYsmqlsWxa7mDSLMwa6dZ9rrIdtrrVYRnDRH0="   crossorigin="anonymous"></script>
<script src='Scripts/main.js' type='text/javascript'></script>
<link href='CSS/reset-meyer.css' rel='stylesheet' type="text/css">
<link href='CSS/main.css' rel='stylesheet' type="text/css">
</head>    
<body> 
<!--Header-->
<header class='header'>
    <?php
      require 'Includes/Header.php';
    ?>
 </header>
   
<!--Main Content-->
<div class='maincontent'>
    <section id='overview'>
       <h1>Welcome to Sandy's Pet Shop!!!</h1><br>
        <p>We are McKinney’s premier grooming facility that truly understands how you and your pet want to be treated.We have been selected by our clients as McKinney’s “BEST” grooming salon 2016, 2017, & 2018 in multiple publications</p> <br>
        <p>We know how much you love your dog, and we want to help you show how much you care.</p><br>
        <p>Your dog will feel soft and smell sweet after a visit to our salon. We offer a wide range of services including trims, brush-outs, ear cleaning, and anal gland expression to keep your dog not just looking good, but healthy and happy.</p><br>
       
       <h1>Services<br></h1>
       <ul>
           <li>Bathing</li>
           <li>Coat Trims</li>
           <li>De-fur Brushing</li>
           <li>Extra Long Brushing Sessions</li>
           <li>Nail Trimming</li>
           <li>Nail Filling</li>
           <li>Teeth Brushing</li>
       </ul>
    </section>
    
    <section id='dogs'>
         <h1>Best Services For Dogs & Cats<br></h1><br>
        <img src='Images/dogs.jpg' alt="dogs"> <br>    
        <img src='Images/cats.jpg' alt="cats">        
    </section>
       
</div>

<!--Footer--> 
    <footer class='footer'>
        <?php
        require 'Includes/Footer.php';
        ?>
    </footer>
</body>
</html>