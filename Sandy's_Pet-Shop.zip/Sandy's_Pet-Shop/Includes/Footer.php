<footer id='footer'>
    <a id='localservices' href='http://www.mckinneyanimalhospital.com/' target='_blank'>Local Services</a>
    <p>Hours of Operation: Mon-Sat 8am - 5pm  Sun: Closed 
    <a id='login' href='login.php' target='_blank'>Admin</a> </p>
</footer>