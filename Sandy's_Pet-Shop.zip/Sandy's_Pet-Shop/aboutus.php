<!DOCTYPE HTML>

<?php
    $pgTitle = 'About Us';
?>

<html>
<head>
<meta charset="utf-8">
<meta name='viewport' content='initial-scale=1.0, width=decive-width'/>
<title><?php echo $pgTitle; ?></title>
<script   src="https://code.jquery.com/jquery-3.0.0.min.js"   integrity="sha256-JmvOoLtYsmqlsWxa7mDSLMwa6dZ9rrIdtrrVYRnDRH0="   crossorigin="anonymous"></script>
<script src='Scripts/main.js' type='text/javascript'></script>
<link href='CSS/reset-meyer.css' rel='stylesheet' type="text/css">
<link href='CSS/main.css' rel='stylesheet' type="text/css">
</head>    
<body> 
<!--Header-->
<header class='header'>
    <?php
      require 'Includes/Header.php';
    ?>
 </header>
   
<!--Main Content-->
<div class='maincontent'>
    <section id='overview'>
         <h1>Our Mission</h1><br>
         <p>
             Sandy's Pet Shop provides quality pet grooming services for both dogs and cats.  We can accommodate all of your dog grooming and cat grooming needs.  We are devoted to making you and your pet feel comfortable with the best grooming results. We are experience groomers and are commited to keeping your pet happy through warmth, gentleness and professionalisim. </p><br>
             <p>We strive to make your pet experience a very good one, and to keep your pet looking great and happy.</p><br>
             <p>Our facility is clean and sanitary and we do everything in our power to ensure the health of every pet. </p><br>
             
          <h1>Our Amazing Staff</h1><br>
         <ul>
            <li>Caroline</li>
            <li>Sophia</li>
            <li>Joer</li>
            <li>Jenn</li>
            <li>Scarlett</li>
            <li>Mike</li>
            <li>Chloe</li>
         </ul>   
    </section>
    
    <section id='grouppic'>
        <h1>Our Staff</h1><br>
        <img src='Images/grouppic.jpg' alt='Staff'>        
    </section>
</div>

<!--Footer--> 
    <footer class='footer'>
        <?php
        require 'Includes/Footer.php';
        ?>
    </footer>
</body>
</html>