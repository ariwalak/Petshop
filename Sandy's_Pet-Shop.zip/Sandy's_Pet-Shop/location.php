<!DOCTYPE HTML>
<?php
    $pgTitle = 'Store Location';
?>
<html>
<head>
<meta charset="utf-8">
<meta name='viewport' content='initial-scale=1.0, width=decive-width'/>
<title><?php echo $pgTitle; ?></title>
<script   src="https://code.jquery.com/jquery-3.0.0.min.js"   integrity="sha256-JmvOoLtYsmqlsWxa7mDSLMwa6dZ9rrIdtrrVYRnDRH0="   crossorigin="anonymous"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
<link href='CSS/reset-meyer.css' rel='stylesheet' type="text/css">
<link href='CSS/main.css' rel='stylesheet' type="text/css">
</head>    
<body> 
<!--Header-->
<header class='header'>
    <?php
      require 'Includes/Header.php';
    ?>
 </header>
   
<!--Main Content-->
<div class='maincontent'>
    <section id='overview'>
        <h1>Address</h1><br>
        <p>Sandy's Pet Shop</p>
        <p>3000 Eldorado Pkwy, McKinney, TX 75070</p><br>
        <h1>Directions</h1><br>
        <p> From SRT-121 North:  Take the exit toward Hardin Blvd/Chelsea Blvd. Use the 2nd from the left lane to continue on TX-121 N/S Srv Rd. Turn left onto Hardin Blvd. Sandy's Pet Shop is at the cornor of Hardin Blvd and Eldorado pkwy.</p><br>
        <p> From 75 SOUTH:  Take exit 38C to merge onto TX-121 S/Sam Rayburn Tollway. Take the exit toward Hardin Blvd/Chelsea Blvd. Turn left onto Hardin Blvd. Sandy's Pet Shop is at the cornor of Hardin Blvd and Eldorado pkwy.</p><br>
        <h1>Hours of Operation</h1><br>
        <ul>
            <li>Mon: 8am to 5pm</li>
            <li>Tues: 8am to 5pm</li>
            <li>Wed: 8am to 5pm</li>
            <li>Thurs: 8am to 5pm</li>
            <li>Fri: 8am to 5pm</li>
            <li>Sat: 8am to 5pm</li>
            <li>Sun: Closed</li>
        </ul>
        
    </section>

<!--Google Map-->
    <section id='mapcontainer'>
       <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9446.032482399165!2d-96.67001930578252!3d33.17011057299936!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864c16aae0956b4b%3A0x5946293dc93b5798!2s3000+Eldorado+Pkwy%2C+McKinney%2C+TX+75070!5e0!3m2!1sen!2sus!4v1526006566315" width="550" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>   
    </section>
</div>

<!--Footer--> 
    <footer class='footer'>
        <?php
        require 'Includes/Footer.php';
        ?>
    </footer>
</body>
</html>